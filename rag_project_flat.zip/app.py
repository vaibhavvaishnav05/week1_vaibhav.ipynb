"""
app.py
-------
Streamlit interface for the RAG system.

Run with (from inside this same folder):
    streamlit run app.py
"""

import tempfile
import streamlit as st

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from rag_pipeline import RAGPipeline

st.set_page_config(page_title="Document Q&A (RAG)", page_icon="📄")
st.title("📄 Document Question Answering (RAG)")
st.caption("Upload a document, then ask questions grounded in its content.")

with st.sidebar:
    st.header("Settings")
    provider = st.selectbox("LLM provider", ["anthropic", "openai", "cohere", "local"], index=0)
    chunk_size = st.slider("Chunk size (words)", 100, 1000, 500, step=50)
    overlap = st.slider("Chunk overlap (words)", 0, 200, 50, step=10)
    top_k = st.slider("Chunks retrieved per question", 1, 10, 4)
    st.markdown(
        "API keys are read from environment variables "
        "(`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `COHERE_API_KEY`), "
        "e.g. via a `.env` file. The `local` provider needs no key."
    )

if "pipeline" not in st.session_state:
    st.session_state.pipeline = None
if "history" not in st.session_state:
    st.session_state.history = []

uploaded_file = st.file_uploader("Upload a PDF or text file", type=["pdf", "txt", "md"])

if uploaded_file is not None:
    if st.button("Index document"):
        with tempfile.NamedTemporaryFile(delete=False, suffix="_" + uploaded_file.name) as tmp:
            tmp.write(uploaded_file.read())
            tmp_path = tmp.name

        with st.spinner("Loading, chunking, and embedding document..."):
            pipeline = RAGPipeline(
                llm_provider=provider,
                chunk_size=chunk_size,
                chunk_overlap=overlap,
                top_k=top_k,
            )
            n_chunks = pipeline.ingest(tmp_path)
            st.session_state.pipeline = pipeline
            st.session_state.history = []

        st.success(f"Indexed {n_chunks} chunks. Ask a question below.")

if st.session_state.pipeline is not None:
    question = st.text_input("Ask a question about the document")
    if st.button("Ask") and question:
        with st.spinner("Retrieving context and generating answer..."):
            result = st.session_state.pipeline.ask(question)
        st.session_state.history.insert(0, result)

    for item in st.session_state.history:
        st.markdown(f"**Q: {item['question']}**")
        st.write(item["answer"])
        with st.expander("Sources used"):
            for i, src in enumerate(item["sources"], 1):
                st.markdown(f"**[{i}]** (score={src['score']})")
                st.text(src["chunk"][:400] + ("..." if len(src["chunk"]) > 400 else ""))
        st.divider()
else:
    st.info("Upload and index a document to get started.")
