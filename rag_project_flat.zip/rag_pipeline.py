"""
rag_pipeline.py
----------------
Wires together every stage into a single, reusable pipeline:
  ingest(file_path)  -> load, chunk, embed, index
  ask(question)      -> embed query, retrieve, augment, generate

All modules live in this same folder, so imports are flat (no package).
"""

from typing import Dict
from document_loader import load_document
from text_chunker import chunk_text
from vector_store import VectorStore
from llm import generate_answer


class RAGPipeline:
    def __init__(
        self,
        embedding_model: str = "all-MiniLM-L6-v2",
        llm_provider: str = "anthropic",
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        top_k: int = 4,
    ):
        self.vector_store = VectorStore(embedding_model=embedding_model)
        self.llm_provider = llm_provider
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.top_k = top_k
        self._ingested = False

    def ingest(self, file_path: str) -> int:
        raw_text = load_document(file_path)
        chunks = chunk_text(raw_text, chunk_size=self.chunk_size, overlap=self.chunk_overlap)
        self.vector_store.build(chunks)
        self._ingested = True
        return len(chunks)

    def ask(self, question: str) -> Dict:
        if not self._ingested:
            raise RuntimeError("No document ingested yet. Call ingest() first.")

        retrieved = self.vector_store.search(question, k=self.top_k)
        context_chunks = [chunk for chunk, score in retrieved]
        answer = generate_answer(question, context_chunks, provider=self.llm_provider)

        return {
            "question": question,
            "answer": answer,
            "sources": [{"chunk": chunk, "score": round(score, 4)} for chunk, score in retrieved],
        }
