"""
text_chunker.py
----------------
Stage 2 of the RAG pipeline: Text Chunking.
Splits raw document text into overlapping, word-bounded chunks.
"""

import re
from typing import List


def clean_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
    if overlap >= chunk_size:
        raise ValueError("overlap must be smaller than chunk_size")

    text = clean_text(text)
    words = text.split(" ")

    chunks = []
    start = 0
    while start < len(words):
        end = start + chunk_size
        chunk_words = words[start:end]
        chunk = " ".join(chunk_words).strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(words):
            break
        start = end - overlap
    return chunks


if __name__ == "__main__":
    sample = "word " * 1200
    result = chunk_text(sample, chunk_size=500, overlap=50)
    print(f"Produced {len(result)} chunks")
    for i, c in enumerate(result):
        print(i, len(c.split(" ")), "words")
