"""
vector_store.py
----------------
Stages 3-6 of the RAG pipeline: Embedding Creation, Vector Database,
Query Embedding, and Context Retrieval.

Uses sentence-transformers (local, no API key) for embeddings and
FAISS for fast in-memory similarity search.
"""

from typing import List, Tuple


class VectorStore:
    def __init__(self, embedding_model: str = "all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(embedding_model)
        self.index = None
        self.chunks: List[str] = []

    def build(self, chunks: List[str]) -> None:
        import faiss
        if not chunks:
            raise ValueError("No chunks provided to build the vector store.")

        self.chunks = chunks
        embeddings = self.model.encode(chunks, show_progress_bar=True, convert_to_numpy=True)
        embeddings = embeddings.astype("float32")
        faiss.normalize_L2(embeddings)

        dim = embeddings.shape[1]
        self.index = faiss.IndexFlatIP(dim)
        self.index.add(embeddings)

    def search(self, query: str, k: int = 4) -> List[Tuple[str, float]]:
        import faiss
        if self.index is None:
            raise RuntimeError("Vector store is empty. Call build() first.")

        query_vec = self.model.encode([query], convert_to_numpy=True).astype("float32")
        faiss.normalize_L2(query_vec)

        scores, indices = self.index.search(query_vec, k)
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            results.append((self.chunks[idx], float(score)))
        return results

    def save(self, dir_path: str) -> None:
        import faiss, json, os
        os.makedirs(dir_path, exist_ok=True)
        faiss.write_index(self.index, os.path.join(dir_path, "index.faiss"))
        with open(os.path.join(dir_path, "chunks.json"), "w", encoding="utf-8") as f:
            json.dump(self.chunks, f)

    def load(self, dir_path: str) -> None:
        import faiss, json, os
        self.index = faiss.read_index(os.path.join(dir_path, "index.faiss"))
        with open(os.path.join(dir_path, "chunks.json"), "r", encoding="utf-8") as f:
            self.chunks = json.load(f)
