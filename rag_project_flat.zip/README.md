# Document Q&A with RAG (Retrieval-Augmented Generation)

Every file in this project sits in **one single folder** — no subfolders,
no packages, no import path issues. Just download the whole folder and run.

## Files

| File | Purpose |
|---|---|
| `document_loader.py` | Stage 1: extracts text from PDF/TXT/MD |
| `text_chunker.py` | Stage 2: splits text into overlapping chunks |
| `vector_store.py` | Stages 3–6: embeddings (MiniLM) + FAISS similarity search |
| `llm.py` | Stage 7: sends question + retrieved context to an LLM |
| `rag_pipeline.py` | Combines everything into `ingest()` / `ask()` |
| `main.py` | Command-line interface |
| `app.py` | Streamlit web interface |
| `requirements.txt` | Dependencies |
| `.env.example` | Template for your API key |

## Setup

Make sure all files above are in the **same folder**, then from inside
that folder:

```bash
pip install -r requirements.txt
cp .env.example .env      # then edit .env and add your API key
```

## Usage

### Command line

```bash
python main.py your_document.pdf --provider anthropic
```

Type questions at the `You:` prompt. Type `exit` to quit.

Options: `--provider {anthropic,openai,cohere,local}`, `--chunk-size 500`,
`--overlap 50`, `--top-k 4`.

### Web UI

```bash
streamlit run app.py
```

Open the printed local URL, upload a document, click **Index document**,
then ask questions.

## Troubleshooting

- **`ModuleNotFoundError`**: means a `.py` file isn't in the same folder
  as `main.py`/`app.py`. Since this project is flat (no subfolders),
  just make sure every file above is directly inside one folder — not
  nested, not spread across different locations.
- **`pip` version errors**: `requirements.txt` uses `>=` minimums, not
  exact pins, so pip will pick whatever compatible version is available.

## Extending

- Better chunking: split by sentence/paragraph instead of raw word count.
- Different embedding models: change `all-MiniLM-L6-v2` in `vector_store.py`.
- Hybrid search: combine FAISS with keyword search (e.g. `rank_bm25`).
- Re-ranking: re-score top-k results with a cross-encoder model.
- Persistence: `VectorStore.save()` / `.load()` avoid re-embedding each run.
