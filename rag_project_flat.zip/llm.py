"""
llm.py
-------
Stage 7 of the RAG pipeline: Answer Generation.

Supports multiple providers so you can use whichever API key you have:
  - "anthropic"  -> Claude (needs ANTHROPIC_API_KEY)
  - "openai"     -> GPT models (needs OPENAI_API_KEY)
  - "cohere"     -> Cohere command models (needs COHERE_API_KEY)
  - "local"      -> flan-t5-base via transformers, fully offline, no key
"""

import os
from typing import List

PROMPT_TEMPLATE = """You are a helpful assistant answering questions using ONLY the provided context.
If the answer isn't contained in the context, say you don't know instead of guessing.

Context:
{context}

Question: {question}

Answer:"""


def build_prompt(question: str, context_chunks: List[str]) -> str:
    context = "\n\n---\n\n".join(context_chunks)
    return PROMPT_TEMPLATE.format(context=context, question=question)


def generate_with_anthropic(prompt: str, model: str = "claude-sonnet-4-6") -> str:
    import anthropic
    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    resp = client.messages.create(
        model=model,
        max_tokens=500,
        messages=[{"role": "user", "content": prompt}],
    )
    return resp.content[0].text


def generate_with_openai(prompt: str, model: str = "gpt-4o-mini") -> str:
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    resp = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=500,
        temperature=0.2,
    )
    return resp.choices[0].message.content


def generate_with_cohere(prompt: str, model: str = "command-r") -> str:
    import cohere
    client = cohere.Client(os.environ["COHERE_API_KEY"])
    resp = client.chat(model=model, message=prompt, temperature=0.2)
    return resp.text


_local_pipeline = None


def generate_with_local(prompt: str, model: str = "google/flan-t5-base") -> str:
    global _local_pipeline
    if _local_pipeline is None:
        from transformers import pipeline
        _local_pipeline = pipeline("text2text-generation", model=model)
    result = _local_pipeline(prompt, max_new_tokens=300)
    return result[0]["generated_text"]


PROVIDERS = {
    "anthropic": generate_with_anthropic,
    "openai": generate_with_openai,
    "cohere": generate_with_cohere,
    "local": generate_with_local,
}


def generate_answer(question: str, context_chunks: List[str], provider: str = "anthropic") -> str:
    if not context_chunks:
        return "I couldn't find any relevant information in the document to answer that."
    if provider not in PROVIDERS:
        raise ValueError(f"Unknown provider '{provider}'. Choose from {list(PROVIDERS)}")
    prompt = build_prompt(question, context_chunks)
    return PROVIDERS[provider](prompt)
