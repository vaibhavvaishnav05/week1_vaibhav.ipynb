"""
document_loader.py
-------------------
Stage 1 of the RAG pipeline: Document Ingestion.
Loads raw text out of PDFs or plain text files.
"""

from pathlib import Path


def load_pdf(file_path: str) -> str:
    from pypdf import PdfReader
    reader = PdfReader(file_path)
    pages_text = [page.extract_text() or "" for page in reader.pages]
    return "\n".join(pages_text)


def load_txt(file_path: str) -> str:
    return Path(file_path).read_text(encoding="utf-8", errors="ignore")


def load_document(file_path: str) -> str:
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"No such file: {file_path}")

    suffix = path.suffix.lower()
    if suffix == ".pdf":
        text = load_pdf(str(path))
    elif suffix in (".txt", ".md"):
        text = load_txt(str(path))
    else:
        raise ValueError(f"Unsupported file type: {suffix}. Use .pdf, .txt, or .md")

    if not text.strip():
        raise ValueError(
            f"No extractable text found in {file_path}. "
            "If this is a scanned PDF, it needs OCR first."
        )
    return text
