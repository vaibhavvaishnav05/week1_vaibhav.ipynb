"""
main.py
--------
Command-line interface for the RAG system.

Usage:
    python main.py your_document.pdf --provider anthropic

Then type questions interactively. Type 'exit' to quit.

Run this from inside the same folder as the other .py files.
"""

import argparse

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from rag_pipeline import RAGPipeline


def main():
    parser = argparse.ArgumentParser(description="RAG-based document Q&A")
    parser.add_argument("document", help="Path to a .pdf, .txt, or .md file")
    parser.add_argument(
        "--provider",
        default="anthropic",
        choices=["anthropic", "openai", "cohere", "local"],
        help="Which LLM to use for answer generation",
    )
    parser.add_argument("--chunk-size", type=int, default=500)
    parser.add_argument("--overlap", type=int, default=50)
    parser.add_argument("--top-k", type=int, default=4)
    args = parser.parse_args()

    print(f"Loading and indexing '{args.document}' ...")
    pipeline = RAGPipeline(
        llm_provider=args.provider,
        chunk_size=args.chunk_size,
        chunk_overlap=args.overlap,
        top_k=args.top_k,
    )
    n_chunks = pipeline.ingest(args.document)
    print(f"Done. Indexed {n_chunks} chunks. Ask questions below (type 'exit' to quit).\n")

    while True:
        question = input("You: ").strip()
        if question.lower() in ("exit", "quit"):
            break
        if not question:
            continue

        result = pipeline.ask(question)
        print(f"\nAnswer: {result['answer']}\n")
        print("Sources used:")
        for i, src in enumerate(result["sources"], 1):
            preview = src["chunk"][:150].replace("\n", " ")
            print(f"  [{i}] (score={src['score']}) {preview}...")
        print()


if __name__ == "__main__":
    main()
