"""
============================================================
 Document Question Answering System (RAG)
============================================================

THEORY: What is Retrieval-Augmented Generation?
------------------------------------------------
A plain language model answers questions purely from what it memorized
during training. That causes two problems:
  1. It cannot know about YOUR private documents (notes, resumes, PDFs).
  2. It can "hallucinate" - state facts confidently that are wrong.

RAG fixes this by giving the model an open-book exam instead of a
closed-book one. Before answering, the system:
  1. Searches your documents for the passages most relevant to the question
     (RETRIEVAL)
  2. Inserts those passages into the prompt as context
     (AUGMENTATION)
  3. Asks the language model to answer USING that context
     (GENERATION)

This grounds the answer in real, verifiable text instead of the model's
internal (and possibly outdated or wrong) memory.

------------------------------------------------------------
 Pipeline stages implemented in this file
------------------------------------------------------------
 1. Document Ingestion   -> load_document()
 2. Text Chunking        -> chunk_text()
 3. Embedding Creation    -> build_index()   (SentenceTransformer)
 4. Vector Database       -> build_index()   (in-memory numpy matrix)
 5. Query Processing      -> answer_question() step 1
 6. Context Retrieval     -> retrieve()
 7. Answer Generation     -> generate_answer()
============================================================
"""

import os
import re
import sys
import json
import numpy as np


# ------------------------------------------------------------------
# STAGE 1: DOCUMENT INGESTION
# ------------------------------------------------------------------
def load_document(path: str) -> str:
    """
    Loads a PDF or .txt file and returns its raw text.

    THEORY: Documents come in messy, unstructured formats (PDF layout,
    headers/footers, inconsistent spacing). Ingestion's only job is to
    turn that into one clean string of plain text we can work with in
    later stages.
    """
    ext = os.path.splitext(path)[1].lower()

    if ext == ".pdf":
        from pypdf import PdfReader
        reader = PdfReader(path)
        pages = [page.extract_text() or "" for page in reader.pages]
        text = "\n".join(pages)
    elif ext in (".txt", ".md"):
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    else:
        raise ValueError(f"Unsupported file type: {ext}")

    # Basic cleanup: collapse excess whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text


# ------------------------------------------------------------------
# STAGE 2: TEXT CHUNKING
# ------------------------------------------------------------------
def chunk_text(text: str, chunk_size: int = 500, overlap: int = 100) -> list[str]:
    """
    Splits text into overlapping word-based chunks.

    THEORY: Why chunk at all?
    - Embedding models and LLM context windows have size limits.
    - Smaller chunks give more PRECISE retrieval: if a whole 50-page
      document were one chunk, the embedding would blur together too
      many topics, and you'd always retrieve "the whole document."
    - Overlap prevents a sentence that spans a chunk boundary from
      losing its meaning (e.g. a definition split awkwardly in half).

    Trade-off: chunks too small -> lose context; chunks too large ->
    lose retrieval precision. chunk_size=500 words with 100-word
    overlap is a reasonable default for a "simple" RAG system.
    """
    words = text.split()
    if not words:
        return []

    chunks = []
    start = 0
    step = max(chunk_size - overlap, 1)
    while start < len(words):
        chunk = " ".join(words[start:start + chunk_size])
        chunks.append(chunk)
        start += step
    return chunks


# ------------------------------------------------------------------
# STAGES 3 & 4: EMBEDDING CREATION + VECTOR DATABASE
# ------------------------------------------------------------------
class VectorStore:
    """
    THEORY: Embeddings
    -------------------
    An embedding model converts a chunk of text into a vector (a list
    of numbers, e.g. 384 dimensions) such that texts with SIMILAR
    MEANING end up as vectors that point in similar directions -
    even if they don't share the same words. ("The cat sat on the mat"
    and "A feline rested on the rug" would land close together.)

    THEORY: Vector database / similarity search
    ---------------------------------------------
    Once every chunk is a vector, finding "relevant" chunks for a
    question becomes a geometry problem: embed the question the same
    way, then find which chunk-vectors are CLOSEST to it. Closeness is
    usually measured with cosine similarity:

        cosine_similarity(a, b) = (a . b) / (||a|| * ||b||)

    A real production system would use a dedicated vector database
    (FAISS, Chroma, Pinecone, Weaviate...) for speed at scale. For a
    simple/learning project, an in-memory numpy matrix does the exact
    same job, just without the industrial-strength indexing tricks
    (e.g. HNSW / IVF) that make searching millions of vectors fast.
    """

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)
        self.chunks: list[str] = []
        self.embeddings: np.ndarray | None = None

    def build(self, chunks: list[str]):
        self.chunks = chunks
        vectors = self.model.encode(chunks, normalize_embeddings=True)
        self.embeddings = np.array(vectors, dtype=np.float32)

    def search(self, query: str, top_k: int = 3) -> list[tuple[str, float]]:
        """Embed the query, then return the top_k most similar chunks."""
        if self.embeddings is None or len(self.chunks) == 0:
            return []

        query_vec = self.model.encode([query], normalize_embeddings=True)[0]
        # Since both query and chunk vectors are normalized, dot product
        # IS cosine similarity.
        scores = self.embeddings @ query_vec
        top_indices = np.argsort(scores)[::-1][:top_k]
        return [(self.chunks[i], float(scores[i])) for i in top_indices]

    def save(self, path: str):
        np.savez(path, embeddings=self.embeddings, chunks=np.array(self.chunks, dtype=object))

    def load(self, path: str):
        data = np.load(path, allow_pickle=True)
        self.embeddings = data["embeddings"]
        self.chunks = list(data["chunks"])


# ------------------------------------------------------------------
# STAGE 7: ANSWER GENERATION
# ------------------------------------------------------------------
def generate_answer(question: str, context_chunks: list[str], provider: str = "anthropic") -> str:
    """
    THEORY: Augmentation + Generation
    -----------------------------------
    We build a prompt that explicitly instructs the model to answer
    ONLY using the retrieved context, and to admit when the context
    doesn't contain the answer (this is what keeps RAG "grounded"
    instead of letting the model fall back on ungrounded guesses).
    """
    context = "\n\n---\n\n".join(context_chunks)
    prompt = f"""You are a helpful assistant answering questions about a document.
Use ONLY the context below to answer. If the answer isn't in the context,
say "I couldn't find that in the document."

Context:
{context}

Question: {question}

Answer:"""

    if provider == "anthropic":
        import anthropic
        client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env
        response = client.messages.create(
            model="claude-sonnet-4-5",
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text

    elif provider == "openai":
        from openai import OpenAI
        client = OpenAI()  # reads OPENAI_API_KEY from env
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
        )
        return response.choices[0].message.content

    else:
        raise ValueError(f"Unknown provider: {provider}")


# ------------------------------------------------------------------
# FULL PIPELINE WRAPPER
# ------------------------------------------------------------------
class RAGSystem:
    """Ties every stage together into one simple interface."""

    def __init__(self, embedding_model: str = "all-MiniLM-L6-v2", llm_provider: str = "anthropic"):
        self.store = VectorStore(embedding_model)
        self.llm_provider = llm_provider

    def ingest(self, file_path: str, chunk_size: int = 500, overlap: int = 100):
        print(f"[1/4] Loading document: {file_path}")
        text = load_document(file_path)

        print("[2/4] Chunking text...")
        chunks = chunk_text(text, chunk_size, overlap)
        print(f"      -> {len(chunks)} chunks created")

        print("[3/4] Creating embeddings + building vector store...")
        self.store.build(chunks)
        print("[4/4] Ready for questions.\n")

    def ask(self, question: str, top_k: int = 3, verbose: bool = True) -> str:
        results = self.store.search(question, top_k=top_k)
        context_chunks = [r[0] for r in results]

        if verbose:
            print("\nRetrieved context (top matches):")
            for i, (chunk, score) in enumerate(results, 1):
                preview = chunk[:150].replace("\n", " ")
                print(f"  [{i}] (score={score:.3f}) {preview}...")

        answer = generate_answer(question, context_chunks, provider=self.llm_provider)
        return answer


# ------------------------------------------------------------------
# CLI ENTRY POINT
# ------------------------------------------------------------------
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python rag_pipeline.py <path_to_document.pdf>")
        sys.exit(1)

    doc_path = sys.argv[1]
    rag = RAGSystem(llm_provider="anthropic")  # set ANTHROPIC_API_KEY env var first
    rag.ingest(doc_path)

    print("Type your questions below (type 'exit' to quit).\n")
    while True:
        q = input("Q: ").strip()
        if q.lower() in ("exit", "quit"):
            break
        if not q:
            continue
        try:
            answer = rag.ask(q)
            print(f"\nA: {answer}\n")
        except Exception as e:
            print(f"Error generating answer: {e}")
            print("(Tip: make sure ANTHROPIC_API_KEY is set in your environment.)\n")
