# Document Question Answering System (RAG)

A simple, fully working Retrieval-Augmented Generation pipeline that answers
questions about your own PDFs or text files.

---

## 1. Theory: What problem does RAG solve?

A language model on its own only "knows" what it saw during training. Ask it
about your resume, your lecture notes, or a paper published last week, and it
either can't answer or it **hallucinates** — states something confidently
that is simply wrong, because it has no real source to check against.

**Retrieval-Augmented Generation (RAG)** fixes this by turning question
answering into an *open-book exam* instead of a *closed-book* one:

| Stage | What it does |
|---|---|
| **Retrieval** | Search your documents for the passages most relevant to the question |
| **Augmentation** | Insert those passages into the model's prompt as context |
| **Generation** | Ask the model to answer *using* that context |

Because the final answer is generated from real retrieved text, RAG systems
are more factually grounded and can answer questions about private,
domain-specific, or newly-created data that the model was never trained on.

---

## 2. Theory: How retrieval actually works

Two ideas make retrieval possible:

**Embeddings.** An embedding model converts a chunk of text into a vector
(e.g. 384 numbers) such that chunks with *similar meaning* — not necessarily
similar wording — end up as vectors pointing in similar directions. "The cat
sat on the mat" and "A feline rested on the rug" land close together even
though they share almost no words.

**Similarity search.** To find relevant chunks for a question, the system
embeds the question the same way, then measures how close each chunk-vector
is to the question-vector, typically using **cosine similarity**:

```
cosine_similarity(a, b) = (a · b) / (‖a‖ × ‖b‖)
```

The chunks with the highest similarity score are the ones retrieved as
context. A production system would store these vectors in a dedicated
**vector database** (FAISS, Chroma, Pinecone, Weaviate) that uses indexing
tricks (HNSW, IVF) to search millions of vectors in milliseconds. This
project uses a plain in-memory NumPy matrix, which computes the exact same
similarity — just without that large-scale indexing speedup, which is fine
at the scale of a handful of documents.

---

## 3. Why chunk text instead of embedding the whole document?

- Embedding models and LLM context windows have size limits.
- A single embedding for an entire 50-page PDF would blur every topic in
  the document together, so every query would just retrieve "the whole
  document" instead of the specific relevant passage.
- Smaller chunks give more *precise* retrieval, at the cost of losing some
  surrounding context — which is why chunks are made to **overlap** (e.g.
  100 words shared between consecutive chunks), so a sentence or idea that
  falls across a chunk boundary isn't cut in a way that destroys its meaning.

---

## 4. System architecture

```
   PDF / TXT file
        |
        v
[1] Document Ingestion   ──  load raw text
        |
        v
[2] Text Chunking          ──  split into overlapping chunks
        |
        v
[3] Embedding Creation      ──  each chunk -> vector (SentenceTransformer)
        |
        v
[4] Vector Database         ──  store all chunk vectors (NumPy matrix)
        |
        |          User Question
        |               |
        |               v
        |     [5] Query Processing  -- embed the question
        |               |
        └──────>[6] Context Retrieval  -- cosine similarity search, top-k chunks
                        |
                        v
              [7] Answer Generation  -- LLM answers using retrieved context
                        |
                        v
                  Final Answer
```

This maps directly onto `rag_pipeline.py`:

| Stage | Function / Class |
|---|---|
| 1. Document Ingestion | `load_document()` |
| 2. Text Chunking | `chunk_text()` |
| 3. Embedding Creation | `VectorStore.build()` |
| 4. Vector Database | `VectorStore` (in-memory) |
| 5. Query Processing | `VectorStore.search()` (query embedding step) |
| 6. Context Retrieval | `VectorStore.search()` (similarity ranking) |
| 7. Answer Generation | `generate_answer()` |

---

## 5. Setup

```bash
pip install -r requirements.txt
```

Set your LLM API key as an environment variable (the code defaults to
Anthropic's Claude, but also supports OpenAI):

```bash
export ANTHROPIC_API_KEY="your-key-here"
# or, if using provider="openai":
# export OPENAI_API_KEY="your-key-here"
```

> Note: the first run downloads the embedding model
> (`all-MiniLM-L6-v2`, ~80MB) from Hugging Face, so you'll need normal
> internet access for that one-time download.

---

## 6. Usage

### Command line

```bash
python rag_pipeline.py path/to/your_document.pdf
```

Then type questions interactively:

```
Q: What is the main idea of the document?
A: ...
```

### As a Python module

```python
from rag_pipeline import RAGSystem

rag = RAGSystem(llm_provider="anthropic")
rag.ingest("my_notes.pdf")

answer = rag.ask("What are the key takeaways?")
print(answer)
```

---

## 7. Example flow

**User question:** "What is the main idea of the document?"

**System process:**
1. Embeds the question.
2. Retrieves the top-k most similar chunks from the vector store.
3. Feeds those chunks + the question to the LLM as context.
4. LLM generates a concise, grounded answer.

---

## 8. Possible improvements (experiments to try)

- **Better chunking**: sentence-aware or semantic chunking instead of fixed
  word counts.
- **Different embedding models**: compare `all-MiniLM-L6-v2` against larger
  models like `bge-large` or `text-embedding-3-large`.
- **Hybrid search**: combine vector similarity with keyword search (BM25)
  for queries where exact terms matter (names, numbers, codes).
- **Re-ranking**: after retrieving top-k candidates, use a cross-encoder to
  re-score and re-order them for higher precision.
- **Swap the vector store**: move from an in-memory NumPy matrix to FAISS
  or Chroma for larger document collections.

---

## 9. Key learnings

- How retrieval and generation combine to ground LLM answers in real data.
- Why retrieval quality directly determines answer quality — a great LLM
  fed the wrong context still gives a wrong answer.
- Practical experience with embeddings, vector similarity, and chunking
  trade-offs.
- How to design a modular pipeline that scales from a single PDF up to a
  full knowledge base.

RAG systems like this one power chatbots, internal knowledge assistants,
enterprise search, and AI documentation tools.
